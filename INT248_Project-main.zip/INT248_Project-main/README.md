# Face_Recognition
# About:
This project can be used where we require to identify the peoples just by cctv or Machine like At petrol pump, shopping mall, etc. Where customers don't require to pay their bill by cash or any physical card like debit card, credit card etc, their Bill can be paid by just verify their faces and amount will be debited from their bank account.

# OpenCV
OpenCV (Open source computer vision) is a library of programming functions mainly aimed at real-time computer vision.[1] Originally developed by Intel, it was later supported by Willow Garage then Itseez (which was later acquired by Intel[2]). The library is cross-platform and free for use under the open-source BSD license.

OpenCV supports some models from deep learning frameworks like TensorFlow, Torch, PyTorch (after converting to an ONNX model) and Caffe according to a defined list of supported layers.[3]. It promotes OpenVisionCapsules. [4], which is a portable format, compatible with all other formats.


# Requirements.

import cv2

import numpy as np

from os import listdir

from os.path import isfile,join
